#include<iostream>

#include "binario.h"

using std::cout;//Salida Estandar
using std::endl;//Fin de linea
using std::cin;// Entrada Estandar

using arbol::binario;//Arbol binario generico

int main (int argc, char *argv[]) {
	
	//crear una instncia del arbol binario
	binario<int> a;
	
	cout<<(a.es_vacio()?
		   "El arbol esta vacio":
		   "El arbol no esta vacio") <<endl;
	
	//insetar datos
	cout<<"insertar datos"<<endl;
	a.insertar(4);
	a.insertar(2);
	a.insertar(1);
	a.insertar(3);
	a.insertar(5);
	a.insertar(6);
	
	cout<<(a.es_vacio()?
		   "El arbol esta vacio":
		   "El arbol no esta vacio") <<endl;
	
	//impriir en preoOrden
	a.preorden();
	cout<<endl;
	a.inorden();
	cout<<endl;
	a.posorden();
	cout<<endl;
	
	//cout<<"Ingrese el dato a eliminar";
	//cin>>dato;
	int dato=4 ;
	
	//eliminar un dato
	a.eliminar(dato);
	
	a.preorden();
	cout<<endl;
	a.inorden();
	cout<<endl;
	a.posorden();
	cout<<endl;
	
	return 0;
}

