Elaborado por : Nicolle Alexandra Monta�o Cifuentes <nicollemontano@unicuca.edu.co>

Desarrolle la implementaci�n de un �rbol binario de b�squeda usando la
representaci�n de arreglos y de estructuras enlazadas.
